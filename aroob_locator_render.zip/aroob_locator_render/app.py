from fastapi import FastAPI, HTTPException, Header
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from datetime import datetime, timezone
from typing import Dict
import secrets, os

app = FastAPI(title="Aroob Locator",
              description="Consent-first, invite-based location sharing (API + Web).",
              version="1.0.0")

static_dir = os.path.join(os.path.dirname(__file__), "web")
app.mount("/web", StaticFiles(directory=static_dir, html=True), name="web")

USERS = {}
INVITES = {}
LAST_LOC: Dict[str, dict] = {}

class InviteIn(BaseModel):
    from_user: str = Field(..., min_length=3)
    to_identifier: str = Field(..., min_length=1)

class InviteOut(BaseModel):
    token: str
    url: str

class LocationIn(BaseModel):
    user_id: str = Field(..., min_length=3, max_length=128)
    lat: float
    lon: float
    ts: datetime
    mode: str = Field(default="live", pattern="^(live|periodic|sos)$")

@app.get("/")
def root():
    return {
        "service": "Aroob Locator",
        "endpoints": {"docs": "/docs", "share_page": "/web/share.html", "viewer_page": "/web/viewer.html"}
    }

@app.post("/invite", response_model=InviteOut)
def create_invite(data: InviteIn):
    token = secrets.token_urlsafe(12)
    INVITES[token] = {"from_user": data.from_user, "to_identifier": data.to_identifier, "created_at": datetime.now(timezone.utc).isoformat()}
    return {"token": token, "url": f"/accept-invite/{token}"}

@app.get("/accept-invite/{token}")
def accept_invite(token: str):
    if token not in INVITES:
        raise HTTPException(status_code=404, detail="Invalid token")
    invite = INVITES[token]
    return {"invite": invite, "token": token, "message": "Paste this token in the Share page and start sharing."}

@app.post("/location/upload")
def upload_location(data: LocationIn, x_consent: str = Header("", convert_underscores=False), x_invite_token: str = Header("", convert_underscores=False)):
    if (x_consent or "").lower() != "yes":
        raise HTTPException(status_code=403, detail="Consent header required (X-Consent: yes).")
    if not x_invite_token:
        raise HTTPException(status_code=403, detail="Invite token required (X-Invite-Token).")
    if x_invite_token not in INVITES:
        raise HTTPException(status_code=403, detail="Invalid invite token.")
    recipient = data.user_id
    USERS.setdefault(recipient, {"user_id": recipient, "accepted_invites": set()})
    USERS[recipient]["accepted_invites"].add(x_invite_token)
    if not (-90.0 <= data.lat <= 90.0 and -180.0 <= data.lon <= 180.0):
        raise HTTPException(status_code=422, detail="Invalid coordinates.")
    LAST_LOC[data.user_id] = {"user_id": data.user_id,"lat": float(data.lat),"lon": float(data.lon),"ts": data.ts.replace(tzinfo=timezone.utc).isoformat(),"mode": data.mode,"updated_at": datetime.now(timezone.utc).isoformat()}
    return {"ok": True, "stored": LAST_LOC[data.user_id]}

@app.get("/location/latest/{user_id}")
def latest_location(user_id: str):
    if user_id not in LAST_LOC:
        raise HTTPException(status_code=404, detail="No location for this user yet.")
    return LAST_LOC[user_id]
