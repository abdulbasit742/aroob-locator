Aroob Locator — Render-ready (single service: API + web)

Deploy steps (you just click, minimal actions):
1) Create a free account at https://render.com and connect GitHub.
2) Create a GitHub repo named "aroob-locator" and upload these files.
3) In Render, click "New" -> "Web Service from Repo" (or "Blueprint").
4) Select "aroob-locator" repo.
5) Build Command:  pip install -r requirements.txt
   Start Command:  uvicorn app:app --host 0.0.0.0 --port $PORT
6) Click Create. After deploy, your app URL will be shown.
   Use:
   - /docs to create an invite token
   - /web/share.html for your friend to share
   - /web/viewer.html for you to view

Important: consent-first only. No covert tracking.
